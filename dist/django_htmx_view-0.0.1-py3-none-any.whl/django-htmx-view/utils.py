from functools import wraps
from typing import Callable, Literal
from django.http import HttpRequest, HttpResponse


def register_htmx_view(
    *,
    method: Literal["GET", "POST"],
) -> Callable[[Callable[..., HttpResponse]], Callable[..., HttpResponse]]:
    def decorator(
        action_function: Callable[..., HttpResponse],
    ) -> Callable[..., HttpResponse]:
        @wraps(action_function)
        def wrap(
            self,
            request: HttpRequest,
            *args: object,
            **kwargs: object,
        ) -> HttpResponse:
            if request.method != method:
                return HttpResponse("", status=405)
            return action_function(self, request, *args, **kwargs)

        return wrap

    return decorator
